<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'subject',
        'message',
        'read',
        'TC'  ,
        'date'  ,
        'number'  ,
        'job'  ,
        'salary'  ,
        'kredi'  ,
        'iban'  ,
        'aytaksit'  ,
        'CreditType'  ,
        'address'  ,
        'bank'  ,
    ];
}

