@extends('layouts.admin.master')

@section('content')
    @include('admin.alert.alert')

    <div class="row">

        </div>
    </div>
@endsection
